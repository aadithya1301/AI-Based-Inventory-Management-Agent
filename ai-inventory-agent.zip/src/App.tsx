import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Package, 
  AlertTriangle, 
  TrendingUp, 
  Bot, 
  User, 
  Loader2, 
  LayoutDashboard, 
  MessageSquare, 
  Settings, 
  ChevronRight,
  Activity,
  Box
} from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function App() {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'System initialized. I am your AI Inventory Intelligence Agent. How can I assist with your logistics today?' }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || isLoading) return;

    const userQuery = query.trim();
    setQuery('');
    setMessages(prev => [...prev, { role: 'user', content: userQuery }]);
    setIsLoading(true);

    try {
      const response = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: userQuery }),
      });

      if (!response.ok) throw new Error('Failed to get response from agent');

      const data = await response.json();
      setMessages(prev => [...prev, { role: 'assistant', content: data.response }]);
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: 'Operational error detected. Please re-issue the command.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickAction = (actionQuery: string) => {
    setQuery(actionQuery);
    // Use a small timeout to allow state to update before submitting
    setTimeout(() => {
      const form = document.querySelector('form');
      form?.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
    }, 10);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5, ease: [0.23, 1, 0.32, 1] }
    }
  };

  return (
    <div className="flex h-screen bg-[#030303] text-zinc-100 font-sans overflow-hidden">
      {/* Sidebar Navigation */}
      <aside className="w-20 border-r border-zinc-800/50 flex flex-col items-center py-8 gap-8 glass z-20">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          whileHover={{ scale: 1.05 }}
          className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center glow-accent cursor-pointer"
        >
          <Box className="text-white" size={24} />
        </motion.div>
        <nav className="flex flex-col gap-6 flex-1">
          {[
            { icon: LayoutDashboard, active: true },
            { icon: MessageSquare, active: false },
            { icon: Activity, active: false },
          ].map((item, i) => (
            <motion.button 
              key={i}
              whileHover={{ scale: 1.1, backgroundColor: 'rgba(39, 39, 42, 1)' }}
              whileTap={{ scale: 0.95 }}
              className={`p-3 rounded-xl transition-all ${item.active ? 'bg-zinc-800 text-blue-400' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              <item.icon size={20} />
            </motion.button>
          ))}
        </nav>
        <motion.button 
          whileHover={{ rotate: 90 }}
          className="p-3 rounded-xl text-zinc-500 hover:text-zinc-300 transition-all"
        >
          <Settings size={20} />
        </motion.button>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Background Glows */}
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/10 blur-[120px] rounded-full pointer-events-none" />

        {/* Top Header */}
        <header className="h-20 px-8 flex items-center justify-between border-b border-zinc-800/30 backdrop-blur-md z-10">
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
          >
            <h1 className="font-display font-bold text-xl tracking-tight">Inventory Intelligence</h1>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
              <span className="font-mono text-[10px] uppercase text-zinc-500 tracking-widest">Agent Online / v2.4.0</span>
            </div>
          </motion.div>
          <motion.div 
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="flex items-center gap-4"
          >
            <div className="px-4 py-2 rounded-full glass text-xs font-medium flex items-center gap-2">
              <User size={14} className="text-zinc-400" />
              aadithyarajesh13@gmail.com
            </div>
          </motion.div>
        </header>

        {/* Content Grid */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="flex-1 flex p-6 gap-6 overflow-hidden z-10"
        >
          {/* Left Column: Chat */}
          <motion.div 
            variants={itemVariants}
            className="flex-[2] flex flex-col glass rounded-3xl overflow-hidden shadow-2xl"
          >
            <div className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth custom-scrollbar">
              <AnimatePresence initial={false}>
                {messages.map((msg, idx) => (
                  <motion.div
                    key={idx}
                    layout
                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                      <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 border border-zinc-700/50 ${msg.role === 'user' ? 'bg-zinc-100 text-zinc-900' : 'bg-zinc-800 text-blue-400'}`}>
                        {msg.role === 'user' ? <User size={18} /> : <Bot size={18} />}
                      </div>
                      <div className={`p-4 rounded-2xl text-sm leading-relaxed shadow-sm ${msg.role === 'user' ? 'bg-blue-600 text-white font-medium' : 'bg-zinc-800/50 border border-zinc-700/30 text-zinc-200'}`}>
                        {msg.content}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              {isLoading && (
                <motion.div 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }} 
                  className="flex justify-start items-center gap-3"
                >
                  <div className="w-10 h-10 rounded-2xl bg-zinc-800 flex items-center justify-center">
                    <Loader2 size={18} className="animate-spin text-blue-400" />
                  </div>
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <motion.div
                        key={i}
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                        className="w-1.5 h-1.5 bg-zinc-500 rounded-full"
                      />
                    ))}
                  </div>
                </motion.div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <form onSubmit={handleSubmit} className="p-4 bg-zinc-900/50 border-t border-zinc-800/50">
              <div className="relative flex items-center">
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Command the agent..."
                  className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl py-4 pl-6 pr-16 text-sm focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 transition-all placeholder:text-zinc-600"
                  disabled={isLoading}
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  type="submit"
                  disabled={isLoading || !query.trim()}
                  className="absolute right-2 p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-500 disabled:opacity-30 transition-all glow-accent"
                >
                  <Send size={18} />
                </motion.button>
              </div>
            </form>
          </motion.div>

          {/* Right Column: Insights */}
          <div className="flex-1 flex flex-col gap-6">
            {/* Quick Actions */}
            <motion.div 
              variants={itemVariants}
              className="glass rounded-3xl p-6 space-y-4"
            >
              <h2 className="font-display font-bold text-sm text-zinc-400 flex items-center gap-2">
                <TrendingUp size={16} />
                QUICK ANALYTICS
              </h2>
              <div className="grid grid-cols-1 gap-3">
                {[
                  { label: 'Check Low Stock', icon: AlertTriangle, query: 'Which items are low in stock?', color: 'text-amber-400' },
                  { label: 'Inventory Count', icon: Package, query: 'How many products are there?', color: 'text-blue-400' },
                  { label: 'Demand Forecast', icon: TrendingUp, query: 'Predict demand for tomorrow', color: 'text-purple-400' },
                ].map((action) => (
                  <motion.button
                    key={action.label}
                    whileHover={{ x: 5, backgroundColor: 'rgba(39, 39, 42, 0.6)' }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleQuickAction(action.query)}
                    className="flex items-center justify-between p-4 rounded-2xl bg-zinc-800/30 border border-zinc-700/30 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <action.icon size={18} className={action.color} />
                      <span className="text-xs font-medium">{action.label}</span>
                    </div>
                    <ChevronRight size={14} className="text-zinc-600 group-hover:text-zinc-400 transition-all" />
                  </motion.button>
                ))}
              </div>
            </motion.div>

            {/* Live Inventory Status */}
            <motion.div 
              variants={itemVariants}
              className="flex-1 glass rounded-3xl p-6 flex flex-col"
            >
              <h2 className="font-display font-bold text-sm text-zinc-400 mb-6 flex items-center gap-2">
                <Activity size={16} />
                LIVE STATUS
              </h2>
              <div className="space-y-6 flex-1">
                {[
                  { name: 'Rice', stock: 20, status: 'Optimal', progress: 80, color: 'bg-green-500' },
                  { name: 'Oil', stock: 5, status: 'Critical', progress: 20, color: 'bg-red-500' },
                  { name: 'Sugar', stock: 12, status: 'Stable', progress: 48, color: 'bg-blue-500' },
                ].map((item, i) => (
                  <motion.div 
                    key={item.name} 
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + (i * 0.1) }}
                    className="space-y-2"
                  >
                    <div className="flex justify-between items-end">
                      <div>
                        <p className="text-xs font-medium text-zinc-200">{item.name}</p>
                        <p className="text-2xl font-display font-bold">{item.stock}</p>
                      </div>
                      <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-md bg-zinc-800 border border-zinc-700 ${item.status === 'Critical' ? 'text-red-400' : 'text-zinc-400'}`}>
                        {item.status}
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-zinc-800 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${item.progress}%` }}
                        transition={{ duration: 1.5, delay: 0.8 + (i * 0.1), ease: "circOut" }}
                        className={`h-full ${item.color}`} 
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
              
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 }}
                className="mt-auto pt-6 border-t border-zinc-800/50"
              >
                <div className="p-4 rounded-2xl bg-blue-600/10 border border-blue-500/20 relative overflow-hidden group">
                  <motion.div 
                    animate={{ x: ['-100%', '200%'] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    className="absolute top-0 left-0 w-1/2 h-full bg-gradient-to-r from-transparent via-blue-400/10 to-transparent skew-x-12"
                  />
                  <p className="text-[10px] font-mono uppercase text-blue-400 tracking-wider mb-1">System Insight</p>
                  <p className="text-xs text-zinc-300 leading-relaxed">
                    Oil stock is below threshold. Recommend reordering 15 units to maintain optimal levels.
                  </p>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </main>
    </div>
  );
}



